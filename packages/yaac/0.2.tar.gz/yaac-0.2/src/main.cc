#include "Program.hh"

int main(int argc, char** argv)
{
    Program p(argc, argv);
    return 0;
}
