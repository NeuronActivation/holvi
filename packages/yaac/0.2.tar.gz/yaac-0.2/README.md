# yaac
Yet another alarm-clock

## Introduction

I don't trust having just alarm in my phone to wake up. Sometimes my phone is on silent or I've pressed a button in my sleep. Few years ago I found a solution to my problem. I used a website on my laptop called [kukuklok.com](https://kukuklok.com/).

I loved this website, however I thought it could be improved.

This project aims to create kukuklok like experience but with:
- Custom mp3s
- Default wakeup time
- Custom colorscheme
- Less resources and internet being used

